#function to print board
#function to check for win or loss or tie
board=["-"]*9

def print_board():
    print(board[0] +" | " + board[1] + " | " + board[2]+" | ")
    print(board[3] +" | " + board[4] + " | " + board[5]+" | ")
    print(board[6] +" | " + board[7] + " | " + board[8]+" | ")

def check_winner():
    if()

def play():
    print_board()
    