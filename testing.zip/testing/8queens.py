import random

def fitness(chromosome):
    clashes = 0
    row_col_clashes = abs(len(chromosome) - len(set(chromosome)))
    clashes += row_col_clashes

    for i in range(len(chromosome)):
        for j in range(len(chromosome)):
            if (i != j):
                dx = abs(i-j)
                dy = abs(chromosome[i] - chromosome[j])
                if(dx == dy):
                    clashes += 1
    return 28 - clashes

def crossover(x, y):
    n = len(x)
    c = random.randint(0,n-1)
    return x[0:c] + y[c:n]

def mutate(x):
    n = len(x)
    c = random.randint(0,n-1)
    m = random.randint(1,n-1)
    x[c] = m
    return x

population_size=100
generations=1000
mutation_probability=0.03

population=[random.sample(range(1,9),8) for _ in range(population_size)]

for i in range(generations):
    
    population=sorted(population,key=lambda x:fitness(x),reverse=True)

    
    if fitness(population[0])==28:
        break
    
   
    new_population=[]
    
   
    s=int((10*population_size)/100)
    new_population.extend(population[:s])
    s=int((90*population_size)/100)
    for _ in range(s):
        parent1=random.choice(population[:50])
        parent2=random.choice(population[:50])
        child=crossover(parent1,parent2)
        if random.uniform(0.0,1.0) <= mutation_probability:
            child=mutate(child)
        new_population.append(child)
    
    population=new_population

print("Solution: ",population[0])